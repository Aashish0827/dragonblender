-DESCRIPTION OF RIG------------------------------------------------------

skeleton bones are on layer 2 in the armature tab and
the main bone and elbow controller bones are located 
on the layer below layer 1. press "M" to move selected 
bones to different layers

some transforms are locked, you can unlock them in object/bone properties
under "transform" at the top

some bones inherit its parent bone's rotation and some don't, you can 
change it in the bone properties tab under "relations"
-------------------------------------------------------------------------
this was made before 2.8 so stuff might be janky

topology namely on the wings are trash, the thin skin parts have
no thickness, which causes issues with normals, smooth shading, 
and texturing. applied a bandaid fix using edgesplit modifier and
creasing

he's my good little boy, be nice to him pls <3

-UncleSalad